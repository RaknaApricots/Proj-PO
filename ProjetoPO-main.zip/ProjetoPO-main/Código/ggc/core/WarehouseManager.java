package ggc.core;

//FIXME import classes (cannot import from pt.tecnico or ggc.app)

import java.io.Serializable;
import java.io.IOException;
import java.io.FileNotFoundException;

import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.ObjectInputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.ObjectOutputStream;

import ggc.core.exception.*;
import java.util.List;
import java.util.ArrayList;


public class WarehouseManager {

  /** Name of file storing current warehouse. */
  private String _filename = null;
  /** The wharehouse itself. */
  protected Warehouse _warehouse = new Warehouse(); 
  
  
  public int currentDay() { return _warehouse.getDate(); }
  public void daysToAdvance ( int xDays ) throws ImpossibleDateException { _warehouse.advanceDays(xDays); }
  public Balance currentBalance() { return _warehouse.getBalance(); }


  /**
   * @@throws MissingFileAssociationException                   
   * @@throws FileNotFoundException
   * @@throws IOException
   */
  public void save() throws MissingFileAssociationException, FileNotFoundException, IOException  {
    if (_filename == null)
      throw new MissingFileAssociationException();

    try(ObjectOutputStream out = new ObjectOutputStream( new BufferedOutputStream( new FileOutputStream(_filename) ) )){
      out.writeObject(_warehouse);
    }

  }


  /**
   * @@param filename                  
   * @@throws FileNotFoundException
   * @@throws IOException  
   */
  public void saveAs(String filename) throws FileNotFoundException, IOException {
    _filename = filename;
    try { save(); } catch(MissingFileAssociationException mfae) {/*Nothing to do. Will never happen.*/}
  }


  /**
   * @@param filename
   * @@throws UnavailableFileException
   * @@throws ClassNotFoundException
   */
  public void load(String filename) throws UnavailableFileException, ClassNotFoundException  {
    try ( ObjectInputStream in = new ObjectInputStream( new BufferedInputStream(new FileInputStream(filename)) ) ) {
      _warehouse = (Warehouse) in.readObject();
      _filename = filename;
    } catch ( IOException e) {
      throw new UnavailableFileException( filename );
    }
  }


  /**
   * @param textfile
   * @throws ImportFileException
   */
  public void importFile(String textfile) throws ImportFileException {
    try {
      _warehouse.importFile(textfile);
    } catch ( BadEntryException | IOException e) {
      throw new ImportFileException(textfile, e);
    }
  }





  /**************
   * 
   *  Product Layer
   * 
   */
  public List<Product> showAllProducts() { return cloneProductList(_warehouse.getProducts()); }

  public List<Batch> showAllBatches() { return cloneBatchList(_warehouse.getBatches()); }

  public List<Batch> showBatchesByPartner( String partnerId ) throws BadEntryException { return cloneBatchList(_warehouse.getBatchesOfPartner(partnerId)); }

  public List<Batch> showBatchesByProduct( String productId ) throws BadEntryException { return cloneBatchList(_warehouse.getBatchesOfProduct(productId)); }

  private List<Batch> cloneBatchList(List<Batch> lista) { 
    List<Batch> aux = new ArrayList<>();
    for(Batch n : lista)
        aux.add(n);
    return aux; 
  }

  private List<Product> cloneProductList(List<Product> lista) { 
    List<Product> aux = new ArrayList<>();
    for(Product n : lista)
        aux.add(n);
    return aux; 
  }

  private List<Partner> clonePartnerList(List<Partner> lista) { 
    List<Partner> aux = new ArrayList<>();
    for(Partner n : lista)
        aux.add(n);
    return aux; 
  }

  /**************
   * 
   *  Partner Layer
   * 
   */
  public List<Partner> showAllPartners() { return clonePartnerList(_warehouse.getPartners()); }

  public Partner showPartner( String id ) throws BadEntryException { return _warehouse.getPartner(id); }

  public void registerPartner ( String id , String name , String address ) throws PartnerAlreadyExistsException { _warehouse.addPartner(id,name,address); }

  public void toggleNotifications(String partnerId ,String productId) throws BadEntryException { _warehouse.toggleNotifications(partnerId,productId); }

  // not working
  //public List<Acquisition> showPartnerAcquisitions(String partnerId) throws BadEntryException { return _warehouse.PartnerAcquisitions(partnerId); }

  // not working
  //public List<Sales> showPartnerSales(String partnerId) throws BadEntryException { return _warehouse.PartnerSales(partnerId); }





  /**************
   * 
   *  Transaction Layer
   * 
   */
  /*
  
  public void showTransaction(int id) {}

  public void registerBreakdownTransaction(String partnerId, String productId, int amount ) {}

  public void registerSaleTransaction(String partnerId, String productId, int amount , String finalDay ) {}

  public void registerAcquisitionTransaction(String partnerId, String productId, int amount , float price ) {}

  //public void registerAcquisitionTransaction(String partnerId, String productId, int amount , float price , Map<String,Integer> recipe ) {}

  public void receivePayment( int transactonId ) {}

  */
}
