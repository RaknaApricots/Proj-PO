package ggc.core;

/**
 * Class that creates a Sell object that extends Transaction.
 * 
 * Creates a product using a boolean to know if it's late, an price, the day of paiment  and the same as:
 * @see Transaction.java
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */
public class Sell extends Transaction {
    
    /**
     * @param _late : identifies if the sell transaction is late
     * @param _actualPrice : price to pay
     * @param _payment : day of the paiment
     */
    private boolean _late;
    private float _actualPrice;
    private Time _paymentDay;

    /**
     * Default Constructor: Sets @param _actualPrice with @param actualPrice and
     * uses the super for the constructor of:
     * @see Transaction.java
     * 
     * @param nProducts
     * @param price
     * @param time
     * @param product
     * @param warehouse
     * @param parteners
     * @param actualPrice
     */
    public Sell( int nProducts, float price,Time time,Product product,Warehouse warehouse,Partner parteners, float actualPrice){
        super( nProducts, price, time, product, warehouse, parteners);
        _actualPrice = actualPrice;
    }

    /**
     * Sets the paiment day
     * @param paymentDay
     */
    public void Paid(Time paymentDay){_paymentDay = paymentDay;}

    /**
     * getter: gets @param _actualPrice
     * @return @param _actualPrice
     */
    public float getActualPrice(){return _actualPrice;}
    

    
}
