package ggc.core;

import java.util.List;
import java.util.ArrayList;
import static java.util.Arrays.asList;
import java.io.Serializable; 

/**
 * Class that creates a Status object.
 * 
 * Creates a Status object which has a rank and status
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */

public class Status implements Serializable{

    /** Serial number for serialization. */
    private static final long serialVersionUID = 3L;

    /**
     * @param _rank : rank
     * @param _status : status
     */
    private static List<String> _rank;
    private String _status;
    

    /**
     * Overload Constructor: Creates a Status with an the default rank list
     */
    protected Status() { this( new ArrayList<> ( asList("NORMAL","SUPER","ELITE") ) ); }

    /**
     * Default Constructor: creates Status in a rank list adnd base status of said rank list
     * @param rank
     */
    protected Status(List<String> rank) { 
        _rank = rank;
        _status = _rank.get(0); 
    }

    /**
     * Promotes(advances) status to the next status rank(index) in the rank list 
     */
    protected void promote() {
        int i = _rank.lastIndexOf( _status );
        if ( i+1 < _rank.size() )
            _status = _rank.get(i+1);
    }

    /**
     * Demotes(goes back) status to the previous status rank(index) in the rank list 
     */
    protected void demote() {
        int i = _rank.lastIndexOf( _status );
        if ( i != 0 )
            _status = _rank.get(i-1);  
    }


    /**
     * toString method that return the string @param _status
     * @return @param _status
     */
    public String toString(){ return _status; }
}