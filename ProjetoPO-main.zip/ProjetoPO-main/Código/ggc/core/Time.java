package ggc.core;

import ggc.core.exception.ImpossibleDateException;
import java.io.Serializable; 

/**
 * Class that creates a Time object.
 * 
 * Creates a Status object which has a date
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */

public class Time implements Serializable {
    /** Serial number for serialization. */
    private static final long serialVersionUID = 2L;

    /**
     * @param _date : date
     */
    private int _date;

    /**
     * Default Constructor: Creates a Time object starting at 0
     */
    Time() { _date = 0; }

    /**
     * Overload Constructor: Creates a Time object starting at:
     * @param date
     */
    Time(int date) { _date = date; }

    /**
     * Adder: Adds @param nDays to @param _date
     * @param nDays
     * @throws ImpossibleDateException : if @param nDays < 0
     */
    protected void advanceDays (int nDays) throws ImpossibleDateException { 
        if (nDays < 0)
            throw new ImpossibleDateException(nDays);
        _date += nDays;
    }

    //Accessible outside the core

    /**
     * getter: gets @param _date
     * @return @param _date
     */
    public int getDate() { return _date; }

    /**
     * toString method: returns @param _date as String
     * @return String @param _date
     */
    public String toString() { return String.valueOf(_date); }

}
