package ggc.core;

/**
 * Class that creates Disagregations.
 * 
 * Creates disagregations giving them an id, number of products, the product, a reference to the warehouse,
 * time and  partner.
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */

public class Disagregation extends Transaction {

    /**
    * Default Constructure of the Disagregation subclass which extends the abstract class Transaction.
    * Only uses the super class constructor.
    * @see Transaction.java
    * @see Transaction()
    *
    */
    public Disagregation( int nProducts, double price,Time time,Product product,Warehouse warehouse,Partner parteners){
        super( nProducts, price, time, product, warehouse, parteners);
    }

    
}
