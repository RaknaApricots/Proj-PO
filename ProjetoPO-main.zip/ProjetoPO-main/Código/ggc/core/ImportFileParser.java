package ggc.core;

import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.Reader;

import ggc.core.exception.BadEntryException;
import ggc.core.exception.PartnerAlreadyExistsException;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class ImportFileParser {

  private Warehouse _store;

  public ImportFileParser(Warehouse w) { _store = w; }


  void parseFile(String filename) throws IOException, BadEntryException {
    try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
      String line;
      while ((line = reader.readLine()) != null)
        parseLine(line);
    }
  }

  private void parseLine(String line) throws BadEntryException {
    String[] components = line.split("\\|");

    switch (components[0]) {
      case "PARTNER":
        parsePartner(components, line);
        break;
      case "BATCH_S":
        parseSimpleProduct(components, line);
        break;

      case "BATCH_M":
        parseAggregateProduct(components, line);
        break;
        
      default:
        throw new BadEntryException("Invalid type element: " + components[0]);
    }
  }

  //PARTNER|id|nome|endereço
  private void parsePartner(String[] components, String line) throws BadEntryException {

    if (components.length != 4)
      throw new BadEntryException("Invalid partner with wrong number of fields (4): " + line);
    
    String id = components[1];
    String name = components[2];
    String address = components[3];
    
    try { 
        _store.addPartner(id,name,address); 
    } catch ( PartnerAlreadyExistsException paee ) {
        throw new BadEntryException("Invalid partner already exists: " + paee.getId() );
    }

  }

  //BATCH_S|idProduto|idParceiro|prec ̧o|stock-actual
  private void parseSimpleProduct(String[] components, String line) throws BadEntryException {
    if (components.length != 5)
      throw new BadEntryException("Invalid number of fields (4) in simple batch description: " + line);
    
    String idProduct = components[1];
    String idPartner = components[2];
    double price = Double.parseDouble(components[3]);
    int stock = Integer.parseInt(components[4]);
    
    _store.addProduct(idProduct);
    Product product = _store.getProduct(idProduct);
    Partner partner = _store.getPartner(idPartner);

    _store.addBatch( new Batch(partner,product,stock,price) );
  }
   
  //BATCH_M|idProduto|idParceiro|prec ̧o|stock-actual|agravamento|componente-1:quantidade-1#...#componente-n:quantidade-n
  private void parseAggregateProduct(String[] components, String line) throws BadEntryException {
    if (components.length != 7)
      throw new BadEntryException("Invalid number of fields (7) in aggregate batch description: " + line);
    
    String idProduct = components[1];
    String idPartner = components[2];
    Map<Product,Integer> recipe = buildRecipe( components[6] );

    _store.addProduct( new DerivatedProduct( idProduct , Double.parseDouble(components[5]) , recipe ) ); 
    
    Product product = _store.getProduct(idProduct);
    Partner partner = _store.getPartner(idPartner);
    double price = Double.parseDouble(components[3]);
    int stock = Integer.parseInt(components[4]);

    _store.addBatch( new Batch(partner,product,stock,price) );
  }

  private Map<Product,Integer> buildRecipe( String components ) throws BadEntryException {
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<Integer> quantities = new ArrayList<>();
    
    for (String component : components.split("#")) {
    String[] recipeComponent = component.split(":"); 
    products.add( _store.getProduct(recipeComponent[0]) );
    quantities.add( Integer.parseInt(recipeComponent[1]) );
    }

    return (Map<Product,Integer>) buildMap(products,quantities);
  }

  private Map<Product,Integer> buildMap( List<Product> keys , List<Integer> values ) throws BadEntryException {

    if( keys.size() != values.size() )
        throw new BadEntryException("Invalid recipe: ");

    Map<Product,Integer> aux = new HashMap<>();

    for ( int i=0 ; i<keys.size() ; i++ )
        aux.put( keys.get(i) , values.get(i) );

    return aux;
  }


}

