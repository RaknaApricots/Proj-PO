package ggc.core;

import java.io.Serializable;

/**
 * Class that creates MeanOfDelivery object.
 * 
 * Creates a MeanOfDelivery object giving them a way
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */

public class MeanOfDelivery implements Serializable,Comparable {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 8L;
    /**
     * @param _way : String variable that tells the way to deliver
     */
    private String _way;

    /**
     * Default Constructor: Creates Entity object with a @param _way variable
     * with the default "App" value 
     */
    MeanOfDelivery() { this("App"); }

    /**
     * Overload Constructor: Creates Entity object with the @param _way
     * variable with the information of @param way
     * @param way
     */
    MeanOfDelivery(String way) { _way = way; }

    /**
     * Method Override of toString: returns @param _way as the default toString return
     */
    @Override
    public String toString() { return _way; }

    /**
     * Method Override of compareTo: Default way of comparing a MeanOfDelivery object with another object @param obj
     * @param obj 
     */
    @Override
    public int compareTo( Object obj ) { return (obj instanceof MeanOfDelivery) ? _way.compareToIgnoreCase( ( (MeanOfDelivery) obj ).toString() ) : 1; }
}
