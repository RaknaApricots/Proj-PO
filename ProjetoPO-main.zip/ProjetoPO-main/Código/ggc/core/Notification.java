package ggc.core;

import java.io.Serializable; 

/**
 * Class that creates a Notification object.
 * 
 * Creates a Notification giving them product, partner, message and price,
 * with the option(boolean) to turn it ON or OFF
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */

public abstract class Notification implements Serializable {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 6L;

    /**
     * @param _notify : variable to turn on or off the notification
     * @param _product : variable to identify the product
     * @param _partner : variable to identify the partner
     * @param _message : variable used to set the message of the notification
     * @param _price : variable to save the price
     */
    private boolean _notify = true;
    private Product _product;
    private Partner _partner;
    private String _message;
    private double _price;

    /**
     * Default Constructor: Creates a Notification type object using:
     * @param partner
     * @param product
     * @param message
     * @param price
     */
    Notification( Partner partner, Product product , String message , double price) {
        _partner = partner;
        _product = product;
        _message = message;
        _price = price;
    }


    /**
     * getter: tells if the Notification is ON or OFF 
     * @return @param _notify
     */
    public boolean isNotify() { return _notify; }

    /**
     * getter: returns the product that the Notification is about
     * @return @param _product
     */
    public Product getProduct() { return _product; }

    /**
     * getter: returns the partner related to the Notification object
     * @return @param _partner
     */
    public Partner getPartner() { return _partner; }
    public String getMessage() { return _message; }
    public double getPrice() { return _price; }
    void toggleNotifications() { _notify = !_notify; }

    /**
     * clonner: creates a clone of a product
     * @return @param Product copy of @param _product
     */
    @Override
    public abstract Notification clone();

}
