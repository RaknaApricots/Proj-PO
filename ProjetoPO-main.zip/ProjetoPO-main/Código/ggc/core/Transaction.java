package ggc.core;

import java.io.Serializable;

/**
 * Abstract Class that creates a Transaction object.
 * 
 * Creates a Transaction object which has an id, number of products,
 * price, completion boolean, payment time, product, warehouse and partner.
 * also the last id
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */

public abstract class Transaction implements Serializable {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 1L;
    private static int _lastId = 0;

    /**
     * @param _id
     * @param _nProducts : number of products
     * @param _price
     * @param _complete : completion indicator
     * @param _payTime : time of payment
     * @param _product
     * @param _warehouse
     * @param _parters
     */
    private int _id;
    private int _nProducts;
    private double _price;
    private boolean _complete;
    private Time _payTime;
    private Product _product;
    private Warehouse _warehouse;
    private Partner _partners;

    /**
     * Default Constructor: Creates a Transaction object using:
     * @param nProducts
     * @param price
     * @param time
     * @param product
     * @param warehouse
     * @param partners
     */
    public Transaction( int nProducts, double price, Time time,Product product,Warehouse warehouse,Partner partners){
        _id = _lastId;
        _lastId++;
        _nProducts = nProducts;
        _price = price;
        _payTime = time;
        _product = product;
        _warehouse = warehouse;
        _partners = partners;
    }

    /**
     * getter: gets @param _id
     * @return @param _id
     */
    public int getId() { return _id; }

    /**
     * getter: gets @param _nProducts
     * @return @param _nProducts
     */
    public int getNProducts() { return _nProducts; }

    /**
     * getter: gets @param _price
     * @return @param _price
     */
    public double getPrice() { return _price; }

    /**
     * getter: gets @param _payTime
     * @return @param _payTime
     */
    public Time getTime() { return _payTime; }

    /**
     * getter: gets @param _product
     * @return @param _product
     */
    public Product getProduct() { return _product; }

    /**
     * getter: gets @param _partners
     * @return @param _partners
     */
    public Partner getPartner() { return _partners; }

    /**
     * getter: gets @param _lastId
     * @return @param _lastId
     */
    public int getLastTransaction() { return _lastId; }

    /**
     * getter: gets @param _complete
     * @return @param _complete
     */
    public boolean isComplete() { return _complete; }
    

    /*public void Payment(Time currentDay){_payTime = currentDay;}
    protected abstract int PriceByDay();
    protected abstract int BasePrice();*/


}

