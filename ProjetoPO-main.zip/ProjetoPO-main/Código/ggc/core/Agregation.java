package ggc.core;


/**
 * Class that creates Agregations.
 * 
 * Creates agregations giving them an id, number of products, the product, a reference to the warehouse,
 * time and  partner.
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */
public class Agregation extends Transaction {

    /**
    * Default Constructure of the Agregation subclass which extends the abstract class Transaction.
    * Only uses the super class constructor.
    * @see Transaction.java
    * @see Transaction()
    *
    */
    public Agregation( int nProducts, double price,Time time,Product product,Warehouse warehouse,Partner parteners){
        super( nProducts, price, time, product, warehouse, parteners);
    }

    
}
