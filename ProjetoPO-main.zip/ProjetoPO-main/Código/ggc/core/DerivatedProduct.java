package ggc.core;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

/**
 * Class that creates a DerivatedProduct object.
 * 
 * Creates a DerivatedProduct giving them a recipe and escalation
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */

public class DerivatedProduct extends Product {
    
    /**
     * @param _recipe : products required to create said DerivateProduct
     * @param _escalation : creation price escalation
     */
    private Map<Product,Integer> _recipe = new HashMap<>();
    private double _escalation;


    /**
     * Overload Constructor: creates a DerivateProduct object in no batches and with:
     * @param name
     * @param escalation
     * @param recipe
     */
    DerivatedProduct(String name, double escalation , Map<Product,Integer> recipe ) {
        this( name , new ArrayList<>() , escalation , recipe );
    }

    /**
     * Default Constructor : creates a DerivateProduct in batches:
     * @param name
     * @param batches
     * @param escalation
     * @param recipe
     */
    DerivatedProduct(String name, List<Batch> batches , double escalation , Map<Product,Integer> recipe ) {
        super(name,batches);
        _escalation = escalation;
        _recipe = recipe;
    }

    /**
     * getter: gets @param _escalation variable
     * @return @param _escalation
     */
    public double getEscalation() { return _escalation; }

    /**
     * getter: gets @param _recipe HashMap
     * @return @param _recipe
     */
    public Map<Product,Integer> getRecipe() { return _recipe; }

    /**
     * Clonner: Clones the DerivateProduct Variable
     * @return new DerivateProduct object
     */
    @Override
    public DerivatedProduct clone() { return new DerivatedProduct(getName(),getBatches(),_escalation,_recipe); }

}
