package ggc.core;

import java.util.List;
import java.util.ArrayList;

import java.util.function.Predicate;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import java.io.Serializable;


/**
 * Class that creates a Product object.
 * 
 * Creates a product giving them a name and batch
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */
public class Product implements Serializable, Comparable {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 5L;

    /**
     * @param _name (String): product name
     */
    private String _name;
    /**
    * @param _batches (Batch): batches that the product is contained in
     */
    private List<Batch> _batches;

    /**
     * Default Constructor: Constructor that receives name and has an empty batch
     * @param name (String): variable used to set _name
     */
    Product( String name ) { this( name , new ArrayList<>() ); }
    /**
     * Overload Constructor: Constructor that receives name and batch
     * @param name (String): variable used to set _name
     * @param batches (Batch): variable used to set _batches
     */
    Product( String name , List<Batch> batches ) { _name = name; _batches = batches; }

    /**
     * Batch list getter
     * @return : _batches(ArrayList)
     */
    List<Batch> getBatches() { return _batches; }

    /**
     * receives a Predicate and creates a list that filtered out the diferent batches 
     * @param comp batch to get from the batch list
     * @return filterde batch list
    */
    List<Batch> getBatches(Predicate<Batch> comp) { return _batches.stream().filter(comp).collect(Collectors.toList()); }
    
    /**
     * Adds a batch to the _batches ArrayList
     * @param x (Batch) : batch that will be added to _batches
     */
    void addBatch(Batch x) { _batches.add(x); }
    
    /**
     * Removes a define the last batch of the type inputed on the batch arrayList _batches 
     * @param x (Batch): batch to remove
     */
    void removeBatch(Batch x) { _batches.remove( _batches.lastIndexOf(x) );}

    // Accessible outside the core

    /**
     * getter: gets _name
     * @return _name
     * @see _name
     */
    public String getId() { return _name; }                    
    public String getName() { return _name; }

    /**
     * searchs the batch list for the most expensive option
     * if it doesn't exist gives a NoSuchElementException Exception
     * @return the most expensive batch
     */
    public double getMaxPrice() { 
        try { return _batches.stream().mapToDouble( i -> i.getPrice() ).max().getAsDouble(); }
        catch( NoSuchElementException nsee ) { return 0; }
    }

    /**
     * getter: gets the total ammount of overhaul products existent in all batches
     * @return int: number of products in all the batches combined
     */
    public int totalStock() { return _batches.stream().mapToInt( i -> i.getNProducts() ).sum(); }

    
    /**
     * clonner: creates a clone of a product
     * @return Product
     */
    @Override
    public Product clone() { return new Product(_name,_batches); }

    /**
     * overide of equal function for proper functioning of search functions on lists
     */
    @Override
    public boolean equals(Object o) {
        if( o instanceof Product ){
            Product p = (Product) o;
            return _name.equalsIgnoreCase( p.getName() );
        }
        return false;  
    }

    /**
     * overide of compareTo function for proper functioning of search functions on lists
     */
    @Override
    public int hashCode() { return getId().toLowerCase().hashCode(); }

    @Override
    public int compareTo(Object o) {
        return (o instanceof Product) ? _name.compareToIgnoreCase( ( (Product) o ).getName() ) : 1;
    }


}
