package ggc.core;

import java.io.Serializable;

/**
 * Class that creates Entity.
 * 
 * Creates a Entity giving them an id, name and  adress.
 * Created for a more generalized code.
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */

public abstract class Entity implements Serializable {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 9L;

    /**
     * @param _id : indentifier
     * @param _name : name of the entity
     * @param _adress : adress of the entity
     */
    private String _id;
    private String _name;
    private String _address;


    /**
     * Default Constructor : Creates an Entity object with an id, name and address.
     * @param id
     * @param name
     * @param address
     */
    Entity( String id, String name, String address ) {
        _id = id;
        _name = name;
        _address = address;
    }

    //Accessible outside the core
    /**
     * getter: gets the @param _id from the Entity object
     * @return @param _id
     */    
    public String getId() { return _id; }

    /**
     * getter: gets the @param _name from the Entity object
     * @return @param _name
     */
    public String getName() { return _name; }

    /**
     * getter: gets the @param _address from the Entity object
     * @return @param _address
     */
    public String getAddress() { return _address; }
}
