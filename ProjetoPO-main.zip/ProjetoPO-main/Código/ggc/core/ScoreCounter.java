package ggc.core;

import java.io.Serializable; 

/**
 * Class that creates a ScoreCounter object.
 * 
 * Creates a product giving them points and status variables
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */

public class ScoreCounter implements Serializable {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 4L;

    /**
     * @param _points : point counter
     * @param _status : status
     */
    private int _points;
    private Status _status;

    /**
     * Overload Constructor: Creates a ScoreCounter with a new Status
     */
    ScoreCounter() { this( new Status() ); }

    /**
     * Default Constructor: creats a ScoreCounter with a status and points starting at 0
     * @param status
     */
    ScoreCounter(Status status) { _status = status; _points = 0; }
 
    /**
     * getter: gets @param _points
     * @return @param _points
     */
    public int getPoints() { return _points; }

    /**
     * getter: gets @param :status
     * @return
     */
    public Status getStatus() { return _status; }

    /**
     * Adder: Adds @param points to @param _points
     * @param points
     */
    protected void addPoints(int points) { _points += points; }
    /**
     * Remover: REmoves @param points of @param _points
     * @param points
     */
    protected void removePoints(int points) { _points -= points; }

    //void updateScoreCounter(Sell trade) {}

}