package ggc.core;

import java.io.Serializable; 

/**
 * Class that creates a Batch object.
 * 
 * Creates a Batch giving them a partner, product, number of products and price
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */

public class Batch implements Serializable {
    
    /** Serial number for serialization. */
    private static final long serialVersionUID = 10L;

    /**
     * @param _partner : variable that saves the partner that provided a batch
     */
    private Partner _partner;

    /**
     * @param _product : variable that stores the product associated with a batch
     */
    private Product _product;

    /**
     * @param _nProducts : variable that stores the quantaty of product in the batch
     */
    private int _nProducts;

    /**
     * @param _price : variable that stores the price of the product
     */
    private double _price;

    /**
     * Constructor: creates a batch receiving:
     * @param provider
     * @param product
     * @param nProducts
     * @param newprice
     */
    Batch(Partner provider, Product product, int nProducts, double newprice ) {
        _partner = provider;
        _product = product;
        _nProducts = nProducts;
        _price = newprice;
    }
    

    /**
     * getter: gets the partner associated with the batch
     * @return @param _partner : partner assossiated with the batch
     */
    public Partner getPartner() { return _partner; }

    /**
     * getter: gets the product associated with the batch
     * @return @param _product: product associated with the batch
     */
    public Product getProduct() { return _product; }

    /**
     * getter: gets the number of products that exist in the batch
     * @return @param _nProducts : quantaty of Product in batch
     */
    public int getNProducts() { return _nProducts; }

    /**
     * getter: gets the price of the product associated with the batch
     * @return @param _price: price of batch
     */
    public double getPrice() { return _price; }


    /**
     * Increases the number of Product in the batch
     * @param value : ammount of Product to add
     */
    void addProducts(int value) {
        if( value > 0 )
            _nProducts += value;
    }

    /**
     * Removes a defined ammount of Product from the batch
     * @param value : ammount of Product to remove from batch
     */
    void removeProducts(int value) {
        if( value > 0 )
            _nProducts -= value;
    }

    /**
     * Clonner: Clones refered batch
     */
    @Override
    public Batch clone() { return new Batch(_partner,_product,_nProducts,_price); }

}
