package ggc.core;

/**
 * Class that creates NewExistence object which extends Notification.
 * 
 * Creates a MeanOfDelivery object from the Notification Constructor
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */
public class NewExistence extends Notification {

    /**
     * Default Constructor: Creates a NewExistance using super
     * @param partner
     * @param product
     * @param p
     */
    NewExistence( Partner partner, Product product , double p) {
        super( partner , product , "NEW" , p );
    }


    /**
     * Clonner: Clones the NewExistance object
     * @return new NewExistance
     */
    @Override
    public NewExistence clone() { return new NewExistence(getPartner(),getProduct(),getPrice()); }

}
