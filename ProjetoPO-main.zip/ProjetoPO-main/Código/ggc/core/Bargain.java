package ggc.core;

/**
 * Class that creates a Bargain object that extends Notification.
 * 
 * Creates a Bargain with that has the same variables as a Notification but
 * with a fixed message of "Bargain"
 * @see Notification.java
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */

public class Bargain extends Notification {

    /**
     * Default Constructor: just a super but with a fixed message variable
     * @see Notification()
     * 
     * @param partner
     * @param product
     * @param price
     */
    Bargain( Partner partner, Product product , double price ) {
        super( partner , product , "BARGAIN" , price );
    }
    
    /**
     * Cloner made for Bargain type objects
     */
    @Override
    public Bargain clone() { return new Bargain(getPartner(),getProduct(),getPrice()); }

}
