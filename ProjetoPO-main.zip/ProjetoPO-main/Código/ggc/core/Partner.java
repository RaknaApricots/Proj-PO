package ggc.core;

import java.util.function.Predicate;
import java.util.List;
import java.util.ArrayList;
import java.util.Stack;

/**
 * Class that creates Partner that extends Entity.
 * 
 * Creates a Partner object giving them a score, a MeansOfDeliveryManager, notifications and a transaction list
 * and all the other variables from :
 * @see Entity.java 
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */

public class Partner extends Entity implements Comparable {

    /**
     * @param _score : saves the score of the partner
     * @param _wayManager : saves all the means of the delivery of the partner
     * @param _notifications : saves all the notifications of the partner
     * @param _history : saves all the transactions of the partner
     */
    private ScoreCounter _score;
    private MeanOfDeliveryManager _wayManager;
    private List<Notification> _notifications = new ArrayList<>();
    private List<Transaction> _history = new Stack<>();


    /**
     * Overload Constructor: Creates a Partner with a new score and mean of felivery
     * @param id
     * @param name
     * @param address
     */
    Partner( String id, String name, String address ) {
        this( id, name, address , new ScoreCounter() , new MeanOfDelivery() );
    }


    /**
     * Overload Constructor: Creates a Partner with a new mean of delivery
     * @param id
     * @param name
     * @param address
     * @param score
     */
    Partner( String id, String name, String address, ScoreCounter score ) {
        this( id, name, address , score , new MeanOfDelivery() );
    }

    
    /**
     * Overload Constructor: Creates a Partner with a new score
     * @param id
     * @param name
     * @param address
     * @param way
     */
    Partner( String id, String name, String address, MeanOfDelivery way ) {
        this( id, name, address , new ScoreCounter() , way );
    }

    /**
     * Default Constructor: Creates a Partner Variable using super and:
     * @param id
     * @param name
     * @param address
     * @param score
     * @param way
     */
    Partner( String id, String name, String address, ScoreCounter score, MeanOfDelivery way ) {
        super( id, name, address);
        _wayManager = new MeanOfDeliveryManager(way);
        _score = score;
    }
   
    /**
     * Toggles ON/OFF the first notification that fulfills the condition @param seletor
     * Finds the first product in the notifications that is the same as the one inputed and turns it ON/OFF
     * @param seletor : receivers @param product and uses it on the equals method
     * @param product
     */
    void toggleNotifications(Product product) { /* criar exceção MissingNotificationsException */
        Predicate<Notification> seletor = i -> i.getProduct().equals(product);
        _notifications.stream().filter(seletor).findFirst().get().toggleNotifications(); 
    }

    /**
     * Adder: Adds a Notification @param x to the @param _notifications List
     * @param x
     */
    void addNotifications(Notification x) { _notifications.add(x); }

    /**
     * Remover: Removes all Notification from @param _notifications List
     * by creating a new ArrayList on the @param _notifications
     */
    void removeAllNotifications() { _notifications = new ArrayList<>(); }
    //void updateHistoric(Transaction lastOne) { _history.add(lastOne); }

    /**
     *Receives a Predicate @param p and filters the @param _history according to it
     and gets the total price sum of all the transactions that satisfy said condition  
     * @param p : filter
     * @return total price of filtered transactions
     */
    private double totalTransactionHelper(Predicate<Transaction> p) { return _history.stream().filter(p).mapToDouble( i -> i.getPrice() ).sum(); }

    //Accessible outside the core

    /**
     * getter: Gets the price of all transactions
     * @see totalTransactionHelper
     * @return total price of all transactions
     */
    public double getTotalPurchases() { return totalTransactionHelper( i -> i instanceof Purchase ); }

    /**
     * getter: gets the total price of all the sales
     * @see totalTransactionHelper
     * @return total price of sales
     */
    public double getSellsMade() { return totalTransactionHelper( i -> i instanceof Sell ); }

    /**
     * getter: gets the total price of all sales that have been completed
     * @see totalTransactionHelper
     * @return
     */
    public double getSellsPaid() { return totalTransactionHelper( i -> i instanceof Sell && i.isComplete() ); }

    /**
     * getter: gets the @param _score
     * @return @param _score
     */
    public ScoreCounter getScore() { return _score; }

    /**
     * getter: gets all the Notifications using the method clone() to mantain security
     * @return a clone of @param _notifications, @param aux
     */
    public List<Notification> getNotifications() { 
        List<Notification> aux = new ArrayList<>() ;
        for(Notification n : _notifications)
            aux.add( n.clone() );
        _notifications = new ArrayList<>();
        return aux; 
    }
    
    //public List<Transaction> getHistory() { return _history; }

    /**
     * getter: gets @param _wayManager
     * @return @param _wayManager
     */
    public MeanOfDeliveryManager getWayManager() { return _wayManager; }
    
    @Override
    public boolean equals(Object o) { 
        if( o instanceof Partner ) {
            Partner p = (Partner) o;
            return getId().equalsIgnoreCase( p.getId() );
        }
        return false;
    }
 
    /**
     * Override method of hashCode for proper use in accordance with @param _id
     */
    @Override
    public int hashCode() { return getId().toLowerCase().hashCode(); }
    
    /**
     * Override method for proper compareTo method using the id, name and address for comparison
     */
    @Override
    public int compareTo(Object o) {
        if( o instanceof Partner ){
            Partner p = (Partner) o;
            int i = compareId(p);
            return i==0 ? ( (i = compareName(p))==0 ? compareAddress(p):i  ):i;
        }
        return 1;
    }

    /**
     * Compare method for comparing ID variables of partners
     * @param p
     * @return
     */
    private int compareId(Partner p) { return getId().compareToIgnoreCase( p.getId() ); }

    /**
     * Compare method for comparing name variables of partners
     * @param p
     * @return
     */
    private int compareName(Partner p) { return getName().compareToIgnoreCase( p.getName() ); }

    /**
     * Compare method for comparing address variables of partners
     * @param p
     * @return
     */
    private int compareAddress(Partner p) { return getAddress().compareToIgnoreCase( p.getAddress() ); }

}