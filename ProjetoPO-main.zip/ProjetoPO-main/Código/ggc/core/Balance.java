package ggc.core;

import java.io.Serializable; 

/**
 * Class that creates Balance and modifies it.
 * 
 * Creates a balance giving them a available balance and accounting balance(both float),
 * also allows for their modification usinng methods that increase and decrease 
 * their value.
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */

public class Balance implements Serializable {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 11L;
    
    /**variable that saves the current available balance */
    private float _balanceAvaiable;
    /**variable that saves the current accounting balance */
    private float _accountingBalance;


    /**
     * Overload constructor: receives both available and accounting balance(float)
     * and creates a balance object
     * 
     * @param balanceAvaiable 
     * @param accountingBalance
     */
    Balance(float balanceAvaiable , float accountingBalance ) {
        _balanceAvaiable = balanceAvaiable;
        _accountingBalance = accountingBalance;
    }

    /**
     * default constructor: creates balance starting as zero
     */
    Balance() { this(0,0); }
    
    /***
     * getter of _balanceAvaiable
     * @return float: the vallue of _balanceAvaiable
     */
    public float getBalanceAvaiable() { return _balanceAvaiable; }
    /***
     * getter of _accountingBalance
     * @return float: _accountingBalance
     */
    public float getAccountingBalance() { return _accountingBalance; }

    /**
     * Method to increase available balance
     * @param value (float): ammount to add to _balanceAvailable
     */
    void addBalanceAvaiable(float value) {  _balanceAvaiable += value; }

    /**
     * Method to increase accounting balance
     * @param value (float): ammount to add to _accountingBalance
     */
    void addAccountingBalance(float value) {  _accountingBalance += value; }

    /**
     * Method to decrease available balance
     * @param value (float): ammount to subtract to _availableBalance
     */
    void subtractBalanceAvaiable(float value) {  _balanceAvaiable += value; }

    /**
     * Method to decrease accounting balance
     * @param value (float): ammount to subtract to _accountingBalance
     */
    void subtractAccountingBalance(float value) {  _accountingBalance += value; }
}
