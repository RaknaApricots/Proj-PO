package ggc.core;

import java.io.Serializable;
import java.util.Set;
import java.util.HashSet;

/**
 * Class that creates MeanOfDeliveryManager object.
 * 
 * Creates a MeanOfDeliveryManager object giving them a favourite way of delivery
 * and a Set of all the ways of delivery
 * 
 * @author 99056 96213
 * 
 * @version Intermediate
 * 
 */

public class MeanOfDeliveryManager implements Serializable {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 7L;
    
    /**
     * @param _favouriteWay : the prefered way of delivery
     * @param _ways : all the ways of delivery
     */
    private MeanOfDelivery _favouriteWay;
    private Set<MeanOfDelivery> _ways;

    /**
     * Default Constructor: creates an empty MeanOfDeliveryManager
     */
    MeanOfDeliveryManager() { this( new MeanOfDelivery() ); }

    /**
     * Overload Constructor: creates a MeanOfDeliveryManager with a @param way
     * as the initial way of delivery and sets it as @param _favouriteWay
     * @param way
     */
    MeanOfDeliveryManager(MeanOfDelivery way) {
        _ways = new HashSet<>();
        _ways.add(way);
        _favouriteWay = way;
    }

    /**
     * getter: gets the @param _ways HashSet
     * @return @param _ways
     */
    public Set<MeanOfDelivery> getWays() { return new HashSet<>(_ways); }

    /**
     * getter: gets the @param _favouriteWay variable
     * @return @param favouriteWay
     */
    public MeanOfDelivery getFavouriteWay() { return _favouriteWay; }

    /**
     * Setter: Sets the @param _favouriteWay as @param favouriteWay
     * @param favouriteWay
     */
    protected void setFavouriteWay(MeanOfDelivery favouriteWay) { 
        _ways.add(favouriteWay);
        this._favouriteWay = favouriteWay; 
    }

    /**
     * Adder: Adds a @param way to @param _ways HashSet
     * @param way
     */
    protected void addWay(MeanOfDelivery way) { _ways.add(way); }

}
