package ggc.core;

// FIXME import classes (cannot import from pt.tecnico or ggc.app)

import java.io.Serializable;
import java.io.IOException;
import ggc.core.exception.BadEntryException;
import ggc.core.exception.PartnerAlreadyExistsException;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.Stack;
import java.util.function.Predicate;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.NoSuchElementException;

import ggc.core.exception.ImpossibleDateException;

/**
 * Class Warehouse implements a warehouse.
 */
class Warehouse implements Serializable {

  /** Serial number for serialization. */
  private static final long serialVersionUID = 202109192006L;

  private Balance _balance = new Balance();
  private Time _today = new Time();
  private Set<Partner> _partners = new HashSet<>();
  private Set<Product> _prod = new HashSet<>();
  //private List<Transaction> _history = new Stack<>();

  
  int getDate() { return _today.getDate(); }
  void advanceDays ( int xDays ) throws ImpossibleDateException { _today.advanceDays(xDays); }
  Balance getBalance() { return _balance; }
  List<Partner> getPartners() { return new ArrayList<>(_partners); }
  List<Product> getProducts() { return new ArrayList<>(_prod); }
  List<Batch> getBatches() {
    List<Batch> aux = new ArrayList<>();
      for( Product p : _prod)
        aux.addAll( getBatchesOfProduct(p) );
    return aux;
  }



  Partner getPartner(String id) throws BadEntryException { 
    try{
      Partner p = _partners.stream().filter( i -> i.getId().equalsIgnoreCase(id) ).findFirst().get();
      if( p == null )
        throw new BadEntryException(id);
      return p;
    }catch( NoSuchElementException nsee ) {
      throw new BadEntryException(id); 
    } 
  }


  Product getProduct(String id) throws BadEntryException { 
    try{
    Product g = _prod.stream().filter(i -> i.getName().equalsIgnoreCase(id)).findFirst().get();
    if( g == null )
      new BadEntryException(id);  
    return g;  
    } catch( NoSuchElementException nsee ) {
      throw new BadEntryException(id); 
    } 
  }


  List<Batch> getBatchesOfProduct(String productId ) throws BadEntryException {
    return getBatchesOfProduct( getProduct(productId) );
  }
  private List<Batch> getBatchesOfProduct( Product p ) { return p.getBatches(); }


  List<Batch> getBatchesOfPartner( String partnerId ) throws BadEntryException {
    
    Partner p = getPartner(partnerId);
    Predicate<Batch> comp = j -> j.getPartner().equals(p);
    List<Batch> aux = new ArrayList <> ();
    _prod.stream().forEach( i -> aux.addAll(i.getBatches(comp)) );
    return aux;
  }




  void addProduct(String name) { _prod.add( new Product(name) ); }
  void addProduct( Product p ) { _prod.add(p.clone()); }
  void addBatch(Batch b) { b.getProduct().addBatch(b.clone()); }
  private void removeBatch(Batch b) {
    // to do
  }

  void removePartner(Partner p) { _partners.remove(p); }
  void addPartner(String id, String name, String address) throws PartnerAlreadyExistsException {
    if( !_partners.add( new Partner(id,name,address) ) )
      throw new PartnerAlreadyExistsException( id );
  }
  



  void toggleNotifications(String partnerId , String productId) throws BadEntryException {
    toggleNotifications( getPartner(partnerId), getProduct(productId) );
  }
  void toggleNotifications( Partner p , Product o ) { p.toggleNotifications(o); }


  //List<Transaction> getTransactions() { return _history; }

  /* /** Partner Transactions Identifier (PTI) 
  private List<Transaction> PTI( String partnerId , Class<?> className ) throws BadEntryException {
    return getPartner(partnerId).getHistory().stream().filter(i -> i instanceof className).collect(Collectors.toList()); 
  }

  List<Acquisition> PartnerAcquisitions(String partnerId) throws BadEntryException { return (List<Acquisition>) PTI(partnerId,Acquisition); }
  List<Sale> PartnerAcquisitions(String partnerId) throws BadEntryException { return (List<Sale>) PTI(partnerId,Sale); }
 */


  void aggregate(Partner p) {

  }

  void disaggregate( String partner , int productId , int amount , int toDay ) {

  }

  void sale(String partner , int limitDay , int productId , int amount , int toDay ) {

  }

  // void buy(String partner , int productId , float price , int amount , int toDay , recipe ) {}

  void payment(int transactionId) {

  }


  /**
   * @param txtfile filename to be loaded.
   * @throws IOException
   * @throws BadEntryException
   */
  void importFile(String txtfile) throws IOException, BadEntryException {
    this.clear();
    new ImportFileParser(this).parseFile(txtfile);
  }

  private void clear() {
    _balance = new Balance();
    _partners = new HashSet<>();
    _prod = new HashSet<>();
    //private List<Transaction> _history = new Stack<>();
  }
}
