package ggc.core.exception;

/** Exception for date-related problems. */
public class ImpossibleDateException extends Exception {

    /** Serial number for serialization. */
    private static final long serialVersionUID = 202109091234L; /* troquei os últimos 3 números */

    /** The requested wrongDate. */
    int _wrongDate;

    /** @param date */
    public ImpossibleDateException(int wrongDate) { _wrongDate = wrongDate; }

    /** @return the requested wrongDate */
    public int getWrongDate() { return _wrongDate; }
}
