package ggc.core.exception;

public class PartnerAlreadyExistsException extends Exception {
    /** Serial number for serialization. */
    private static final long serialVersionUID = 202109091822L;

    String _id;

    public PartnerAlreadyExistsException(String id) {
        _id = id;
    }

    public String getId() { return _id; }

}
