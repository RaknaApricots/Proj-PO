package ggc.core;

/**
 * Class that creates a Purchase object that extends Transaction.
 * 
 * Creates a Purchase using the same as:
 * @see Transaction.java
 * 
 * @author 99056(Bernardo Damasceno) 96213(Gerson Ferreira)
 * 
 * @version Intermediate
 * 
 */
public class Purchase extends Transaction {

    /**
     * Default Constructor: uses super to use the constructor of:
     * @see Transaction.java
     * 
     * @param nProducts
     * @param price
     * @param time
     * @param product
     * @param warehouse
     * @param partners
     */
    public Purchase( int nProducts, double price,Time time,Product product,Warehouse warehouse,Partner partners){
        super( nProducts, price, time, product, warehouse, partners);
    }

}
