package ggc.app;

import ggc.core.*;
import java.util.Map;
import java.util.List;
import java.util.Comparator;

public class genericOutput {

    public static Comparator<Batch> compBatch = (i,j) -> {
        int aux = i.getProduct().compareTo(j.getProduct());
        if(aux!=0) 
            return aux;
        aux = i.getPartner().compareTo(j.getPartner());
        if(aux!=0) 
            return aux;
        aux = i.getNProducts() - j.getNProducts();
        if(aux!=0) 
            return -aux;
        return Double.compare( i.getPrice() , j.getPrice() );
    };
    public static Comparator<Product> compProduct = (i,j) -> i.compareTo(j);
    public static Comparator<Partner> compPartner = (i,j) -> i.compareTo(j);

    public static String notificationOutput(Notification n) {
        return n.getMessage() + "|" + n.getProduct().getId() + "|" + doubleToInt(n.getPrice());
    }

    public static String partnerOutput( Partner p , boolean flag ) { 
        StringBuilder aux = new StringBuilder();
        aux.append( p.getId() + "|" );
        aux.append( p.getName() + "|" );
        aux.append( p.getAddress() + "|" );
        aux.append( p.getScore().getStatus() + "|" );
        aux.append( p.getScore().getPoints() + "|" );

        aux.append( doubleToInt( p.getTotalPurchases() ) + "|" );
        aux.append( doubleToInt( p.getSellsMade() ) + "|" );
        aux.append( doubleToInt( p.getSellsPaid() ) );

        if(flag)
            p.getNotifications().stream().forEach( i -> aux.append( "\n" + notificationOutput(i) ) );
        return aux.toString();
    }

    public static String productOutput(Product p) {
        StringBuilder aux = new StringBuilder();
        aux.append( p.getName() + "|");
        aux.append( doubleToInt(p.getMaxPrice()) + "|" );
        aux.append( doubleToInt(p.totalStock()) );
        if( p instanceof DerivatedProduct ) {
            DerivatedProduct dp = (DerivatedProduct) p;
            aux.append( "|" + recipeOutput( dp.getRecipe() ) );
        }
        return aux.toString();
    }

    public static String recipeOutput(Map<Product,Integer> recipe) {
        StringBuilder aux = new StringBuilder();
        for( Product prod : recipe.keySet() ){
            aux.append( prod.getName() );
            aux.append( ":" );
            aux.append( recipe.get(prod) );
            aux.append( "#" );
        }
        return aux.deleteCharAt(aux.length()-1).toString();
    }

    public static String batchOutput(Batch b) {
        return b.getProduct().getId() + "|" + b.getPartner().getId() + "|" + doubleToInt( b.getPrice() ) + "|" + b.getNProducts();
    }

    private static int doubleToInt (double d) { return Double.valueOf(d).intValue(); }
   
    
}
