package ggc.app.products;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import ggc.core.WarehouseManager;
import ggc.core.Batch;
import java.util.List;
import ggc.core.exception.BadEntryException;
import ggc.app.exception.UnknownProductKeyException;

/**
 * Show all products.
 */
class DoShowBatchesByProduct extends Command<WarehouseManager> {

  DoShowBatchesByProduct(WarehouseManager receiver) {
    super(Label.SHOW_BATCHES_BY_PRODUCT, receiver);
    addStringField(Label.SHOW_BATCHES_SUPPLIED_BY_PARTNER, Message.requestProductKey() );
  }

  @Override
  public final void execute() throws CommandException {

    try {
      List<Batch> batches = _receiver.showBatchesByProduct( stringField(Label.SHOW_BATCHES_SUPPLIED_BY_PARTNER) );
      _display.addLine( DoShowAvailableBatches.outputCalculator(batches) ).display();
    } catch( BadEntryException e ) {
      throw new UnknownProductKeyException( e.getEntrySpecification() );
    }

  }

}
