package ggc.app.products;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import ggc.core.WarehouseManager;
import ggc.core.Product;
import static ggc.app.genericOutput.productOutput;
import static ggc.app.genericOutput.compProduct;
import java.util.List;

/**
 * Show all products.
 */
class DoShowAllProducts extends Command<WarehouseManager> {

  DoShowAllProducts(WarehouseManager receiver) {
    super(Label.SHOW_ALL_PRODUCTS, receiver);
  }

  @Override
  public final void execute() throws CommandException {
    _display.addLine( outputCalculator( _receiver.showAllProducts() ) ).display();
  }

  private String outputCalculator(List<Product> p) {
    if( !p.isEmpty() ) {
      StringBuilder aux = new StringBuilder();
      p.stream().sorted(compProduct).forEach( i -> aux.append( productOutput(i) + "\n" ) );
      return aux.deleteCharAt(aux.length()-1).toString();
    }
    return "";
  }
}
