package ggc.app.products;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import ggc.core.WarehouseManager;
import ggc.core.Batch;
import java.util.List;
import ggc.core.exception.BadEntryException;
import ggc.app.exception.UnknownPartnerKeyException;

/**
 * Show batches supplied by partner.
 */
class DoShowBatchesByPartner extends Command<WarehouseManager> {

  DoShowBatchesByPartner(WarehouseManager receiver) {
    super(Label.SHOW_BATCHES_SUPPLIED_BY_PARTNER, receiver);
    addStringField(Label.SHOW_BATCHES_SUPPLIED_BY_PARTNER, Message.requestPartnerKey() ); 
  }

  @Override
  public final void execute() throws CommandException {

    try {
      List<Batch> batches = _receiver.showBatchesByPartner( stringField(Label.SHOW_BATCHES_SUPPLIED_BY_PARTNER) );
      _display.addLine( DoShowAvailableBatches.outputCalculator(batches) ).display();
    } catch( BadEntryException e ) {
      throw new UnknownPartnerKeyException( e.getEntrySpecification() );
    }

  }

}
