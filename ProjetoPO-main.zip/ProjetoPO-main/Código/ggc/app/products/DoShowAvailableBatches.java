package ggc.app.products;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import ggc.core.WarehouseManager;
import ggc.core.Batch;
import static ggc.app.genericOutput.batchOutput;
import static ggc.app.genericOutput.compBatch;
import java.util.List;

/**
 * Show available batches.
 */
class DoShowAvailableBatches extends Command<WarehouseManager> {

  DoShowAvailableBatches(WarehouseManager receiver) {
    super(Label.SHOW_AVAILABLE_BATCHES, receiver);
  }

  @Override
  public final void execute() throws CommandException {
    _display.addLine( outputCalculator(_receiver.showAllBatches()) ).display();
  }

  protected static String outputCalculator(List<Batch> b) {
    if( !b.isEmpty() ) {
      StringBuilder aux = new StringBuilder();
      b.stream().sorted(compBatch).forEach( i -> aux.append( batchOutput(i) + "\n" ) );
      return aux.deleteCharAt(aux.length()-1).toString();
    }
    return "";
  }

}
