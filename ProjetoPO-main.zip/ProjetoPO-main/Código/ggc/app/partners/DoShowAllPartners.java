package ggc.app.partners;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import ggc.core.WarehouseManager;
import ggc.core.Partner;
import static ggc.app.genericOutput.partnerOutput;
import java.util.List;

/**
 * Show all partners.
 */
class DoShowAllPartners extends Command<WarehouseManager> {

  DoShowAllPartners(WarehouseManager receiver) {
    super(Label.SHOW_ALL_PARTNERS, receiver);
  }

  @Override
  public void execute() throws CommandException {
    _display.addLine( outputCalculator(_receiver.showAllPartners()) ).display();
  }

  private String outputCalculator(List<Partner> p) {
    if( !p.isEmpty() ) {
      StringBuilder aux = new StringBuilder();
      p.stream().sorted( (i,j) -> i.compareTo(j) ).forEach( i -> aux.append( partnerOutput(i,false) + "\n" ) );
      return aux.deleteCharAt(aux.length()-1).toString();
    }
    return "";
  }

}
