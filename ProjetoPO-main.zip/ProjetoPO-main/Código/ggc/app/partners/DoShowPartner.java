package ggc.app.partners;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import ggc.core.WarehouseManager;
import static ggc.app.genericOutput.partnerOutput;
import ggc.core.exception.BadEntryException;
import ggc.app.exception.UnknownPartnerKeyException;

/**
 * Show partner.
 */
class DoShowPartner extends Command<WarehouseManager> {

  DoShowPartner(WarehouseManager receiver) {
    super(Label.SHOW_PARTNER, receiver);
    addStringField(Label.SHOW_PARTNER, Message.requestPartnerKey() );
  }

  @Override
  public final void execute() throws CommandException {
    try {
      _display.addLine( partnerOutput( _receiver.showPartner( stringField(Label.SHOW_PARTNER) ) , true ) ).display();
    } catch( BadEntryException e ) {
      throw new UnknownPartnerKeyException( e.getEntrySpecification() );
    }
  }

}
