package ggc.app.main;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import pt.tecnico.uilib.forms.Form;
import ggc.core.WarehouseManager;
import ggc.core.exception.MissingFileAssociationException;
import ggc.app.exception.FileOpenFailedException;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Save current state to file under current name (if unnamed, query for name).
 */
class DoSaveFile extends Command<WarehouseManager> {

  /** @param receiver */
  DoSaveFile(WarehouseManager receiver) {
    super(Label.SAVE, receiver);
  }

  @Override
  public final void execute() throws CommandException {
    try {
      _receiver.save();
    } catch ( MissingFileAssociationException e ) {
      saveAs();
    } catch( IOException e) { throw new FileOpenFailedException( e.getMessage() );  }
  }

  private void saveAs() throws CommandException {
    Form aux = new Form();
    aux.addStringField( Label.SAVE , Message.newSaveAs() );
    aux.parse();
    try{
      _receiver.saveAs( aux.stringField( Label.SAVE ) );
    } catch( IOException e ) {
      throw new FileOpenFailedException( e.getMessage() );
    }
  }

}
