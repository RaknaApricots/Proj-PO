package ggc.app.main;

import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
import ggc.core.WarehouseManager;
import ggc.core.Balance;

/**
 * Show global balance.
 */
class DoShowGlobalBalance extends Command<WarehouseManager> {

  DoShowGlobalBalance(WarehouseManager receiver) {
    super(Label.SHOW_BALANCE, receiver);
  }

  @Override
  public final void execute() throws CommandException {
    _display.addLine( outputCalculator(_receiver.currentBalance()) ).display();
  }
  
  private String outputCalculator(Balance b) {
    return Message.currentBalance( b.getBalanceAvaiable() , b.getAccountingBalance() );
  }
}
